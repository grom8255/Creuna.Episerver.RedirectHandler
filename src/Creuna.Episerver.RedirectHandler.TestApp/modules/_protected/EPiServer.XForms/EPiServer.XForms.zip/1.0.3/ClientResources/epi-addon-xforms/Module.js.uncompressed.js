define("epi-addon-xforms/Module", [
    // dojo
    "dojo/_base/declare",
    // epi
    "epi/_Module",
    "epi/routes"
],

function (
    // dojo
    declare,
    // epi
    _Module,
    routes
) {

    return declare([_Module], {
        // tags:
        //      internal

        initialize: function () {
            // summary:
            //      Initialize the XForms module

            // Initialize xform store
            var registry = this.resolveDependency("epi.storeregistry");

            registry.create("epi.cms.xform", routes.getRestPath({ moduleArea: "EPiServer.XForms", storeName: "xform" }));

            this.inherited(arguments);
        }
    });
});
