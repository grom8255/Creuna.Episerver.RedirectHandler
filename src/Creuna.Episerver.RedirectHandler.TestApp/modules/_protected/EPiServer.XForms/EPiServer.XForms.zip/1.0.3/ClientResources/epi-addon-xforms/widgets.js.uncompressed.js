/* Dummy file to trick the AMD loader when running debug mode */
